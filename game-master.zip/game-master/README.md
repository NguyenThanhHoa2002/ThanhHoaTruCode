# game cờ Caro online html và javascript
# by Thái Sơn
# kiuc company
# https://thaisonit.com
# (C) 2016 Kiuc
# Bản quyền thuộc về Thái sơn & kiuc company
